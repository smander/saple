SAPLE — Symbolic Algebraic Process Logic Engine
================================================

INSTALL (Windows x64)
---------------------

1. Extract saple.exe to a folder of your choice, e.g.:
       C:\Program Files\SAPLE\

2. Add that folder to your PATH:
   - Start menu -> "Edit environment variables for your account"
   - Edit "Path", click "New", paste the folder, OK.

3. Open a new Command Prompt or PowerShell and run:
       saple --version

DOCUMENTATION
-------------

https://saple.cloud/docs/
